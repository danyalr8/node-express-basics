var mongoose=require('mongoose');
mongoose.connect('mongodb://localhost/simplestudentapp');
var db=mongoose.connection;

var StudentSchema=mongoose.Schema({
    name:{
        type:String
    },
    course:{
        type:String
    }
});

var student=module.exports=mongoose.model('student',StudentSchema);

module.exports.createStudent=function(newStudent,callback){
    newStudent.save(callback);
}

module.exports.fetchStudents=function(callback){
    student.find({},callback);
}

module.exports.deleteStudent=function(id,callback){
    student.findByIdAndRemove({_id:id},callback);
};