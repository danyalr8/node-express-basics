var express=require('express');
var router=express.Router();

var student=require('../models/student');
router.get('/',function(req,res){
    student.fetchStudents(function(err,students){
        if(err) throw err;
        res.render('student',{students:students});
    });
});

router.get('/:id',function(req,res){
    student.deleteStudent(req.params.id,function(err){
        if(err)    throw err;
        student.fetchStudents(function(err,students){
            if(err) throw err;
            res.render('student',{students:students});
        });
    })
    
});

router.post('/',function(req,res){
    var name=req.body.name;
    var course=req.body.course;

    req.checkBody('name','Name is required').notEmpty();
    req.checkBody('course','Course is required').notEmpty();

    var errors=req.validationErrors();
    if(errors) {
        student.fetchStudents(function(err,students){
            if(err) throw err;
            res.render('student',{students:students,errors:errors});
        });
    }
    else{
        var newStudent=new student({
            name:name,
            course:course
        });
        student.createStudent(newStudent,function(err,data){
            if(err) throw err;
            student.fetchStudents(function(err,students){
                if(err) throw err;
                res.render('student',{students:students});
            });
        });
    }
});

module.exports=router;